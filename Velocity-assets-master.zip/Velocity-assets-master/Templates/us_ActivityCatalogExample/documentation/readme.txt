Project: Activity Catalog Example
Description: The activity catalog displays a listing of common tasks to help users become more productive with Velocity topologies and services. This is one example of a single activity.
Category: template
Class: Community

Place customActivity.vamf and customActivity/* in /data/activities on a Velocity system running version 8.0 or higher. Navigate to Library/Activity Catalog to see the example card. 