### Project Information:
Project: JUnit Report Template  
Description: Custom report template for Jenkins that creates a JUnit XML report from a parent/child iTest execution (a test that includes nested run steps)   
Category: template  
Class: Community  
  
  

 ----