Project: Jira Report Template
Description: Custom report template for Velocity that allows a user to create a bug in Jira from Velocity
Category: template
Class: Community

Video available at: https://youtu.be/0FFbAGlEoOc
