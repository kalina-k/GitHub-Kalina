### Project Information:
Project: Testcase PassFail Dashboard  
Description: Example Kibana dashboard that displays testcase execution metrics  
Category: dashboard  
Class: Community  
Tags: Execution  
  
Sample Test Execution Dashboard  
Based on pass/fail of test executions.  
Contains the following visualizations:  
- Executions by TestCase  
- Executions Results  
- Executions by Agent  
- Execution Peak Days  
Requires index with name “*report*”  
  
  

 ----