### Project Information:
Project: Cytec  
Description: Cytec RF switch driver for Velocity  
Category: driver  
Class: Community  
  

 ----
1 test case in project
## Test Case File: cytec-if9-mux-single-module-1.0.fftc
### getConnections
### connect
### disconnect
### getUnwrappedPorts
### getPorts
### getDeviceStatus
### getProperties
### addPropToResult
<table><tr><th>Argument</th><th>Description</th></tr>
<tr><td>json</td><tr></tr>
<tr><td>name</td><tr></tr>
<tr><td>val</td><tr></tr></table>

### build_conn_list
### set_location
### set_mux_type
### set_port_list
### validate_port_pair