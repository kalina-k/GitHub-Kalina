Project: Arista L2 Driver
Description: Provides basic commands for management of Arista L2 switches.
Category: driver
Class: Community
Tags: L2
