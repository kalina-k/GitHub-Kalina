Project: Emulated L2 Driver
Description: A NOOP L2 driver useful for testing and validation purposes
Category: driver
Class: Community
Tags: Driver, Emulated, L2

Emulated L2 Driver
Model a device called "Emulated L2 Switch" using the "Layer 2 Switch" switch template, associate it with this driver, and assign it an IP address of 127.0.0.1 (no other properties are required)
Click "Discover" for the driver to auto-populate the port groups and ports
Connect at least two inventory devices to this emulated L2 switch
Create a topology connecting these two devices together with an VLAN connection
Reserve the topology, and the connection light should go green.

