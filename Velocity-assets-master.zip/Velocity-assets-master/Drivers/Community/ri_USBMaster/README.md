### Project Information:
Project: USB Master  
Description: L1 switch driver for USB Master switch  
Category: driver  
Class: Community  

 ----
1 test case in project
## Test Case File: usb_master-1.0.fftc
### connect
### disconnect
### getDeviceStatus
### getPorts
### getProperties