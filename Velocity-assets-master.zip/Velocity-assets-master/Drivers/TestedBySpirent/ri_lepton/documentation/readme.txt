Project: Lepton ColdFusion Driver
Description: This is a supported driver for the 1024 port multirate ColdFusion L1 switch
Category: driver
Class: TestedBySpirent


1) Import the Lepton ColdFusion driver and template (lepton.template.and.driver.zip) in Velocity from Inventory, Resources, Import, Import from Zip
2) Change the Lepton template's parent to "Network Element / Layer 1 Switch"
