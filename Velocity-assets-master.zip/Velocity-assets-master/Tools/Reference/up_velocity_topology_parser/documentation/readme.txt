Project: Velocity Topology Parser
Description: Creates a usable Python object using the topology supplied by Velocity during a test execution
Category: library
Class: Reference
