from datetime import datetime
import sys, getopt


print("[WARNING] This is a warning message")
print("DUT Version : 10.1a")
print("[ERROR] This is an error message")
print("[INFO] Current time: "+ str(datetime.now()))
print("Response Time : 34")
print("Execution issue verified message")
print("Finished: PASSED")
