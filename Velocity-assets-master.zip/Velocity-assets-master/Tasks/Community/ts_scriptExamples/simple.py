from datetime import datetime
import sys, getopt

print("[WARNING] This is a warning message")
print("[ERROR] This is an error message")
print("[INFO] Current time: "+ str(datetime.now()))

print("Execution issue verified message")

print("Finished: PASSED")