import platform
print("[INFO] Running Python version: "+ str(platform.python_version()))
