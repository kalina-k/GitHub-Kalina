Project: ServerTech Power Management
Description: This task powers up and down banks of cable modems using the Server Tech power controller.
Category: task
Class: Community
