# activity-catalog-package
Package for Activity Catalog demo

Currently the files are used for testing purposes. By the end of the release only one full example will remain
